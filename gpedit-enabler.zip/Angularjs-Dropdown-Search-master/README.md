# Angularjs-Dropdown-Search
 A simple angular js dropdown with search plugin
